const t="RepoAI",c=o=>`
${" ".repeat(14-o.length/2)}[${o}]`,e=o=>{console.log(t,c(`${o} Script Loaded`))},n=()=>{console.log(t,c("Background Loaded"))};export{n as b,e as c};
